var http = require('http');
var ML = require('./Modules/Module_Lotto.js');
var template = require('./Modules/Module_template.js');

var port = 3000;
var hostname = '127.0.0.1'; // localhost

http.createServer(function(request, response){
  var html = template.HTML(ML.getLottoNumbers());
  response.writeHead(200);
  response.end(html);
}).listen(port, hostname, function(){
  console.log(`Server is running at http://${hostname}:${port}`);
});
